class ResponseModel{
  int statusCode;
  String response;
  ResponseModel({this.response,this.statusCode});
}